package twobulk

import (
	"fmt"
	"math"
	"math/rand"
	"os"
	"runtime"
	"sync"
	"time"

	"sort"

	"github.com/brentp/vcfgo"
	"github.com/fatih/color"
	"github.com/schollz/progressbar/v3"
)

type BSAstats struct {
	CHROM      string
	POS        int64
	REF        string
	ALT        string
	HighParGT  []int
	LowParGT   []int
	HighBulkGT []int
	HighBulkAD string
	LowBulkGT  []int
	LowBulkAD  string

	HighBulkL int
	HighBulkH int
	LowBulkL  int
	LowBulkH  int
	HighSI    float64
	LowSI     float64

	DeltaSI float64
	Gstat   float64
	ED      float64
	LOD     float64
	BBLogBF float64

	DeltaSIK float64
	Gprime   float64
	EDK      float64
	LODK     float64
	BBLogBFK float64
}

// QTL represents a detected quantitative trait locus
type QTL struct {
	Chrom     string
	Start     int64
	End       int64
	Peak      int64
	Statistic string  // e.g., "DeltaSI", "LOD", etc.
	Value     float64 // Peak value
	Threshold float64 // Significance threshold used
}

type PopulationType string

const (
	F2  PopulationType = "F2"
	F3  PopulationType = "F3"
	BC  PopulationType = "BC"
	RIL PopulationType = "RIL"
)

// Configuration for analysis
type AnalysisConfig struct {
	Population       PopulationType
	BCAltIsRecurrent bool
	WindowSize       int
	NSimulations     int
	Alpha            float64
	MinQTLWidth      int64  // Minimum width in base pairs for QTL
	MergeDistance    int64  // Merge QTLs within this distance
	OutputFile       string // Output TSV file
	PlotFile         string // Output plot file (PNG)
}

func isHomozygous(gt []int) bool {
	if len(gt) == 0 {
		return false
	}
	for _, a := range gt[1:] {
		if a != gt[0] {
			return false
		}
	}
	return true
}

func GStatistic(highBulkAlt, highBulkRef, lowBulkAlt, lowBulkRef int) float64 {
	highBulkTotal := float64(highBulkAlt + highBulkRef)
	lowBulkTotal := float64(lowBulkAlt + lowBulkRef)
	total := highBulkTotal + lowBulkTotal

	if highBulkTotal == 0 || lowBulkTotal == 0 || total == 0 {
		return 0
	}

	expHighAlt := highBulkTotal * float64(highBulkAlt+lowBulkAlt) / total
	expHighRef := highBulkTotal * float64(highBulkRef+lowBulkRef) / total
	expLowAlt := lowBulkTotal * float64(highBulkAlt+lowBulkAlt) / total
	expLowRef := lowBulkTotal * float64(highBulkRef+lowBulkRef) / total

	g := 0.0
	if highBulkAlt > 0 && expHighAlt > 0 {
		g += float64(highBulkAlt) * math.Log(float64(highBulkAlt)/expHighAlt)
	}
	if highBulkRef > 0 && expHighRef > 0 {
		g += float64(highBulkRef) * math.Log(float64(highBulkRef)/expHighRef)
	}
	if lowBulkAlt > 0 && expLowAlt > 0 {
		g += float64(lowBulkAlt) * math.Log(float64(lowBulkAlt)/expLowAlt)
	}
	if lowBulkRef > 0 && expLowRef > 0 {
		g += float64(lowBulkRef) * math.Log(float64(lowBulkRef)/expLowRef)
	}

	return 2 * g
}

func EuclideanDist(refBulk1, altBulk1, refBulk2, altBulk2 int) float64 {
	total1 := float64(refBulk1 + altBulk1)
	total2 := float64(refBulk2 + altBulk2)
	if total1 == 0 || total2 == 0 {
		return 0
	}

	pAlt := float64(altBulk1) / total1
	qAlt := float64(altBulk2) / total2

	// Standard ED method uses distance between allele frequencies
	// SQRT( (p1-p2)^2 + (q1-q2)^2 ) = SQRT( 2 * (p1-p2)^2 )
	return math.Sqrt(2.0 * math.Pow(pAlt-qAlt, 2))
}

func logBeta(a, b float64) float64 {
	la, _ := math.Lgamma(a)
	lb, _ := math.Lgamma(b)
	lab, _ := math.Lgamma(a + b)
	return la + lb - lab
}

// lod calculates the LOD score in log-space to prevent numerical underflow
func lod(ref1, alt1, ref2, alt2 int) float64 {
	n1 := float64(ref1 + alt1)
	n2 := float64(ref2 + alt2)
	total := n1 + n2

	if n1 == 0 || n2 == 0 || total == 0 {
		return 0.0
	}

	p1 := float64(alt1) / n1
	p2 := float64(alt2) / n2
	p0 := float64(alt1+alt2) / total

	// Handle edge cases where p is 0 or 1
	logLik := func(k, n, p float64) float64 {
		if n == 0 {
			return 0
		}
		if p <= 0 {
			if k == 0 {
				return 0
			}
			return -1e10 // Very low likelihood
		}
		if p >= 1 {
			if k == n {
				return 0
			}
			return -1e10
		}
		return k*math.Log(p) + (n-k)*math.Log(1-p)
	}

	logL1 := logLik(float64(alt1), n1, p1) + logLik(float64(alt2), n2, p2)
	logL0 := logLik(float64(alt1), n1, p0) + logLik(float64(alt2), n2, p0)

	return (logL1 - logL0) / math.Log(10)
}

func betaBinomialLogBF(highSucc, highFail, lowSucc, lowFail, N_high, N_low int) float64 {
	// Use small constant prior weight instead of 0.5 * N
	alphaH, betaH := 1.0, 1.0
	alphaL, betaL := 1.0, 1.0

	logAlt := logBeta(alphaH+float64(highSucc), betaH+float64(highFail)) - logBeta(alphaH, betaH)
	logAlt += logBeta(alphaL+float64(lowSucc), betaL+float64(lowFail)) - logBeta(alphaL, betaL)

	alpha0, beta0 := 1.0, 1.0
	logNull := logBeta(alpha0+float64(highSucc+lowSucc), beta0+float64(highFail+lowFail)) - logBeta(alpha0, beta0)

	return logAlt - logNull
}

func biweight(x float64) float64 {
	if x >= 1 {
		return 0
	}
	t := 1 - x*x
	return t * t
}

func tricube(x float64) float64 {
	if x >= 1 {
		return 0
	}
	return math.Pow(1-math.Pow(x, 3), 3)
}

func smoothChromosomeBSA(stats []BSAstats, bandwidth int) {
	n := len(stats)
	if n == 0 {
		return
	}

	for i := 0; i < n; i++ {
		center := stats[i].POS
		var numDelta, numED, numLOD, numBB, numG float64
		var denB, denG float64

		// Look left
		for j := i; j >= 0; j-- {
			d := float64(center - stats[j].POS)
			if d > float64(bandwidth) {
				break
			}
			x := d / float64(bandwidth)
			wB := biweight(x)
			wG := tricube(x)

			numDelta += wB * stats[j].DeltaSI
			numED += wB * stats[j].ED
			numLOD += wB * stats[j].LOD
			numBB += wB * stats[j].BBLogBF
			numG += wG * stats[j].Gstat
			denB += wB
			denG += wG
		}

		// Look right
		for j := i + 1; j < n; j++ {
			d := float64(stats[j].POS - center)
			if d > float64(bandwidth) {
				break
			}
			x := d / float64(bandwidth)
			wB := biweight(x)
			wG := tricube(x)

			numDelta += wB * stats[j].DeltaSI
			numED += wB * stats[j].ED
			numLOD += wB * stats[j].LOD
			numBB += wB * stats[j].BBLogBF
			numG += wG * stats[j].Gstat
			denB += wB
			denG += wG
		}

		if denB > 0 {
			stats[i].DeltaSIK = numDelta / denB
			stats[i].EDK = numED / denB
			stats[i].LODK = numLOD / denB
			stats[i].BBLogBFK = numBB / denB
		}
		if denG > 0 {
			stats[i].Gprime = numG / denG
		}
	}
}

func expectedAF(pop PopulationType, bcAltIsRecurrent bool) float64 {
	switch pop {
	case F2, F3, RIL:
		return 0.5
	case BC:
		if bcAltIsRecurrent {
			return 0.25
		}
		return 0.75
	default:
		return 0.5
	}
}

func simulateAltCount(depth int, p float64, r *rand.Rand) int {
	c := 0
	for i := 0; i < depth; i++ {
		if r.Float64() < p {
			c++
		}
	}
	return c
}

type SimMax struct {
	MaxDelta float64
	MaxED    float64
	MaxG     float64
	MaxLOD   float64
	MaxBB    float64
}

type Thresholds struct {
	Chrom string
	Delta float64
	ED    float64
	G     float64
	LOD   float64
	BB    float64
}

func simulateChromosomeMax(obs []BSAstats, pop PopulationType, bcAltIsRecurrent bool, windowSize int, r *rand.Rand) SimMax {
	p0 := expectedAF(pop, bcAltIsRecurrent)
	sim := make([]BSAstats, len(obs))

	for i, s := range obs {
		hbDP := s.HighBulkL + s.HighBulkH
		lbDP := s.LowBulkL + s.LowBulkH

		altH := simulateAltCount(hbDP, p0, r)
		altL := simulateAltCount(lbDP, p0, r)

		refH := hbDP - altH
		refL := lbDP - altL

		sim[i] = BSAstats{
			CHROM:   s.CHROM,
			POS:     s.POS,
			DeltaSI: (float64(altH) / float64(hbDP)) - (float64(altL) / float64(lbDP)),
			ED:      EuclideanDist(refH, altH, refL, altL),
			Gstat:   GStatistic(altH, refH, altL, refL),
			LOD:     lod(refH, altH, refL, altL),
			BBLogBF: betaBinomialLogBF(altH, refH, altL, refL, hbDP, lbDP),
		}
	}

	smoothChromosomeBSA(sim, windowSize)

	var smax SimMax
	for _, s := range sim {
		smax.MaxDelta = math.Max(smax.MaxDelta, math.Abs(s.DeltaSIK))
		smax.MaxED = math.Max(smax.MaxED, s.EDK)
		smax.MaxG = math.Max(smax.MaxG, s.Gprime)
		smax.MaxLOD = math.Max(smax.MaxLOD, s.LODK)
		smax.MaxBB = math.Max(smax.MaxBB, s.BBLogBFK)
	}
	return smax
}

func estimateThresholds(obs []BSAstats, pop PopulationType, bcAltIsRecurrent bool, windowSize int, nSim int, alpha float64) Thresholds {
	if len(obs) == 0 {
		return Thresholds{Chrom: "", Delta: 0, ED: 0, G: 0, LOD: 0, BB: 0}
	}

	deltas := make([]float64, nSim)
	eds := make([]float64, nSim)
	gs := make([]float64, nSim)
	lods := make([]float64, nSim)
	bbs := make([]float64, nSim)

	bar := progressbar.NewOptions(nSim,
		progressbar.OptionSetDescription("Running permutations"),
		progressbar.OptionSetWidth(40),
		progressbar.OptionShowIts(),
	)

	// Parallelize simulations
	var wg sync.WaitGroup
	numWorkers := runtime.NumCPU()
	simPerWorker := nSim / numWorkers
	
	results := make(chan SimMax, nSim)

	for w := 0; w < numWorkers; w++ {
		wg.Add(1)
		go func(workerID int) {
			defer wg.Done()
			r := rand.New(rand.NewSource(time.Now().UnixNano() + int64(workerID)))
			count := simPerWorker
			if workerID == numWorkers-1 {
				count += nSim % numWorkers
			}
			for i := 0; i < count; i++ {
				results <- simulateChromosomeMax(obs, pop, bcAltIsRecurrent, windowSize, r)
				bar.Add(1)
			}
		}(w)
	}

	go func() {
		wg.Wait()
		close(results)
	}()

	idx := 0
	for m := range results {
		deltas[idx] = m.MaxDelta
		eds[idx] = m.MaxED
		gs[idx] = m.MaxG
		lods[idx] = m.MaxLOD
		bbs[idx] = m.MaxBB
		idx++
	}
	bar.Finish()

	sort.Float64s(deltas)
	sort.Float64s(eds)
	sort.Float64s(gs)
	sort.Float64s(lods)
	sort.Float64s(bbs)

	q := int(float64(nSim) * (1.0 - alpha))
	if q >= nSim {
		q = nSim - 1
	}

	return Thresholds{
		Chrom: obs[0].CHROM,
		Delta: deltas[q],
		ED:    eds[q],
		G:     gs[q],
		LOD:   lods[q],
		BB:    bbs[q],
	}
}

func detectQTLs(stats []BSAstats, threshold float64, statField string, minWidth, mergeDistance int64) []QTL {
	if len(stats) == 0 {
		return nil
	}

	var qtls []QTL
	var currentQTL *QTL

	getStatValue := func(s BSAstats) float64 {
		switch statField {
		case "DeltaSI": return s.DeltaSIK
		case "ED": return s.EDK
		case "LOD": return s.LODK
		case "Gstat": return s.Gprime
		case "BBLogBF": return s.BBLogBFK
		default: return s.DeltaSIK
		}
	}

	for i, s := range stats {
		val := getStatValue(s)
		aboveThresh := math.Abs(val) >= threshold

		if aboveThresh {
			if currentQTL == nil {
				currentQTL = &QTL{
					Chrom: s.CHROM, Start: s.POS, End: s.POS, Peak: s.POS,
					Statistic: statField, Value: val, Threshold: threshold,
				}
			} else {
				currentQTL.End = s.POS
				if math.Abs(val) > math.Abs(currentQTL.Value) {
					currentQTL.Value = val
					currentQTL.Peak = s.POS
				}
			}
		} else if currentQTL != nil {
			if currentQTL.End-currentQTL.Start >= minWidth {
				qtls = append(qtls, *currentQTL)
			}
			currentQTL = nil
		}

		if i == len(stats)-1 && currentQTL != nil {
			if currentQTL.End-currentQTL.Start >= minWidth {
				qtls = append(qtls, *currentQTL)
			}
		}
	}

	if mergeDistance > 0 && len(qtls) > 1 {
		merged := []QTL{qtls[0]}
		for i := 1; i < len(qtls); i++ {
			last := &merged[len(merged)-1]
			if qtls[i].Start-last.End <= mergeDistance && qtls[i].Chrom == last.Chrom {
				if qtls[i].End > last.End { last.End = qtls[i].End }
				if math.Abs(qtls[i].Value) > math.Abs(last.Value) {
					last.Value = qtls[i].Value
					last.Peak = qtls[i].Peak
				}
			} else {
				merged = append(merged, qtls[i])
			}
		}
		qtls = merged
	}
	return qtls
}

func writeResults(statsByChr map[string][]BSAstats, thresholds map[string]Thresholds, qtlsByStat map[string][]QTL, config AnalysisConfig) error {
	qtlFile, err := os.Create(config.OutputFile + "_qtls.tsv")
	if err != nil { return err }
	defer qtlFile.Close()

	fmt.Fprintf(qtlFile, "# QTL Detection Results\n")
	fmt.Fprintf(qtlFile, "# Parameters: Population=%s, WindowSize=%d, Simulations=%d, Alpha=%.3f\n",
		config.Population, config.WindowSize, config.NSimulations, config.Alpha)
	fmt.Fprintf(qtlFile, "Chrom\tStart\tEnd\tPeak\tStatistic\tValue\tThreshold\n")

	for _, qtls := range qtlsByStat {
		for _, qtl := range qtls {
			fmt.Fprintf(qtlFile, "%s\t%d\t%d\t%d\t%s\t%.4f\t%.4f\n",
				qtl.Chrom, qtl.Start, qtl.End, qtl.Peak, qtl.Statistic, qtl.Value, qtl.Threshold)
		}
	}

	statsFile, err := os.Create(config.OutputFile + "_stats.tsv")
	if err != nil { return err }
	defer statsFile.Close()

	fmt.Fprintf(statsFile, "# Smoothed Statistics\n")
	fmt.Fprintf(statsFile, "Chrom\tPos\tDeltaSI\tED\tLOD\tGstat\tBBLogBF\tDeltaSI_thresh\tED_thresh\tLOD_thresh\tGstat_thresh\tBBLogBF_thresh\n")

	for chr, stats := range statsByChr {
		th := thresholds[chr]
		for _, s := range stats {
			fmt.Fprintf(statsFile, "%s\t%d\t%.6f\t%.6f\t%.6f\t%.6f\t%.6f\t%.6f\t%.6f\t%.6f\t%.6f\t%.6f\n",
				s.CHROM, s.POS, s.DeltaSIK, s.EDK, s.LODK, s.Gprime, s.BBLogBFK,
				th.Delta, th.ED, th.LOD, th.G, th.BB)
		}
	}
	return nil
}

func GoodVariants(v *vcfgo.Variant, highPar, highParDP, lowPar, lowParDP, highBulk, highBulkDP, lowBulk, lowBulkDP int) bool {
	indices := []int{highPar, lowPar, highBulk, lowBulk}
	if len(v.Alt()) != 1 { return false }

	for _, idx := range indices {
		if idx >= len(v.Samples) { return false }
		s := v.Samples[idx]
		if len(s.GT) == 0 { return false }
		for _, allele := range s.GT {
			if allele < 0 { return false }
		}
	}

	hpGT, lpGT := v.Samples[highPar].GT, v.Samples[lowPar].GT
	hpDP, lpDP := v.Samples[highPar].DP, v.Samples[lowPar].DP
	hbDP, lbDP := v.Samples[highBulk].DP, v.Samples[lowBulk].DP

	if !isHomozygous(hpGT) || !isHomozygous(lpGT) || hpGT[0] == lpGT[0] {
		return false
	}
	if hpDP < highParDP || lpDP < lowParDP || hbDP < highBulkDP || lbDP < lowBulkDP {
		return false
	}
	return true
}

func RunTwoBulkTwoParents(vcfRdr *vcfgo.Reader, highPar, highParDP, lowPar, lowParDP, highBulk, highBulkDP, lowBulk, lowBulkDP, windowSize int) {
	config := AnalysisConfig{
		Population: F2, BCAltIsRecurrent: false, WindowSize: windowSize,
		NSimulations: 1000, Alpha: 0.05, MinQTLWidth: 100000, MergeDistance: 500000,
		OutputFile: "bsaseq_results", PlotFile: "bsaseq_plots.png",
	}
	RunTwoBulkTwoParentsWithConfig(vcfRdr, highPar, highParDP, lowPar, lowParDP, highBulk, highBulkDP, lowBulk, lowBulkDP, config)
}

func RunTwoBulkTwoParentsWithConfig(vcfRdr *vcfgo.Reader, highPar, highParDP, lowPar, lowParDP, highBulk, highBulkDP, lowBulk, lowBulkDP int, config AnalysisConfig) {
	overallStart := time.Now()
	variantChan := make(chan *vcfgo.Variant, 10000)
	statsChan := make(chan BSAstats, 10000)

	numWorkers := runtime.NumCPU()
	var workerWG sync.WaitGroup

	color.Cyan("============================ Calculating Statistics =============================\n\n")
	bar := progressbar.Default(-1, "Processing variants")

	for i := 0; i < numWorkers; i++ {
		workerWG.Add(1)
		go func() {
			defer workerWG.Done()
			for variant := range variantChan {
				if !GoodVariants(variant, highPar, highParDP, lowPar, lowParDP, highBulk, highBulkDP, lowBulk, lowBulkDP) {
					bar.Add(1)
					continue
				}

				lpGT := variant.Samples[lowPar].GT
				hbGT := variant.Samples[highBulk].GT
				lbGT := variant.Samples[lowBulk].GT
				hbDP, lbDP := variant.Samples[highBulk].DP, variant.Samples[lowBulk].DP

				if hbDP == 0 || lbDP == 0 {
					bar.Add(1)
					continue
				}

				hbRefDep, _ := variant.Samples[highBulk].RefDepth()
				hbAltDeps, _ := variant.Samples[highBulk].AltDepths()
				lbRefDep, _ := variant.Samples[lowBulk].RefDepth()
				lbAltDeps, _ := variant.Samples[lowBulk].AltDepths()

				if len(hbAltDeps) == 0 || len(lbAltDeps) == 0 {
					bar.Add(1)
					continue
				}

				var hbL, hbH, lbL, lbH int
				if hbGT[0] == lpGT[0] {
					hbL, hbH = hbRefDep, hbAltDeps[0]
				} else {
					hbL, hbH = hbAltDeps[0], hbRefDep
				}
				if lbGT[0] == lpGT[0] {
					lbL, lbH = lbRefDep, lbAltDeps[0]
				} else {
					lbL, lbH = lbAltDeps[0], lbRefDep
				}

				hSI, lSI := float64(hbH)/float64(hbDP), float64(lbH)/float64(lbDP)

				statsChan <- BSAstats{
					CHROM: variant.Chromosome, POS: int64(variant.Pos), REF: variant.Reference, ALT: variant.Alt()[0],
					HighParGT: variant.Samples[highPar].GT, LowParGT: variant.Samples[lowPar].GT,
					HighBulkGT: variant.Samples[highBulk].GT, HighBulkAD: fmt.Sprintf("%d,%d", hbRefDep, hbAltDeps[0]),
					LowBulkGT: variant.Samples[lowBulk].GT, LowBulkAD: fmt.Sprintf("%d,%d", lbRefDep, lbAltDeps[0]),
					HighBulkL: hbL, HighBulkH: hbH, LowBulkL: lbL, LowBulkH: lbH,
					HighSI: hSI, LowSI: lSI, DeltaSI: hSI - lSI,
					Gstat: GStatistic(hbH, hbL, lbH, lbL), ED: EuclideanDist(hbL, hbH, lbL, lbH),
					LOD: lod(hbL, hbH, lbL, lbH), BBLogBF: betaBinomialLogBF(hbH, hbL, lbH, lbL, hbDP, lbDP),
				}
				bar.Add(1)
			}
		}()
	}

	go func() {
		for v := vcfRdr.Read(); v != nil; v = vcfRdr.Read() {
			variantChan <- v
		}
		close(variantChan)
	}()

	go func() {
		workerWG.Wait()
		close(statsChan)
	}()

	stats := make([]BSAstats, 0, 100000)
	for s := range statsChan {
		stats = append(stats, s)
	}
	bar.Finish()

	color.Cyan("\n============================ Smoothing Statistics =============================\n\n")
	byChr := make(map[string][]BSAstats)
	for _, s := range stats {
		byChr[s.CHROM] = append(byChr[s.CHROM], s)
	}

	for chr := range byChr {
		sort.Slice(byChr[chr], func(i, j int) bool { return byChr[chr][i].POS < byChr[chr][j].POS })
		smoothChromosomeBSA(byChr[chr], config.WindowSize)
	}

	color.Cyan("\n============================ Estimating Thresholds =============================\n\n")
	thresholds := make(map[string]Thresholds)
	for chr, chrStats := range byChr {
		color.Yellow("Chromosome %s (%d variants)\n", chr, len(chrStats))
		thresholds[chr] = estimateThresholds(chrStats, config.Population, config.BCAltIsRecurrent, config.WindowSize, config.NSimulations, config.Alpha)
	}

	color.Cyan("\n============================ Detecting QTLs =============================\n\n")
	statFields := []string{"DeltaSI", "ED", "LOD", "Gstat", "BBLogBF"}
	qtlsByStat := make(map[string][]QTL)

	for _, sf := range statFields {
		var allQtls []QTL
		thKey := sf
		if sf == "Gstat" { thKey = "G" }

		for chr, chrStats := range byChr {
			var thresh float64
			switch thKey {
			case "DeltaSI": thresh = thresholds[chr].Delta
			case "ED": thresh = thresholds[chr].ED
			case "LOD": thresh = thresholds[chr].LOD
			case "G": thresh = thresholds[chr].G
			case "BBLogBF": thresh = thresholds[chr].BB
			}
			allQtls = append(allQtls, detectQTLs(chrStats, thresh, sf, config.MinQTLWidth, config.MergeDistance)...)
		}
		qtlsByStat[sf] = allQtls
		color.Green("Detected %d QTLs using %s\n", len(allQtls), sf)
	}

	writeResults(byChr, thresholds, qtlsByStat, config)
	generatePlots(byChr, thresholds, config)
	color.Green("\nTotal time: %s\n", time.Since(overallStart).Round(time.Second))
}
